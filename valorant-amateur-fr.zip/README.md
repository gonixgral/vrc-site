# Valorant Amateur France

Un site vitrine pour la scène Valorant amateur en France.

## 🚀 Installation

```bash
npm install
npm run dev
```

## 📦 Build

```bash
npm run build
```

## 🌍 Déploiement

- **Vercel** : push sur GitHub et connecter le repo.
- **Netlify** : build command = `npm run build`, publish directory = `dist/`.
